document.getElementById("test").className += ".circle";
// const atualizaGrafico = document.querySelectorAll("[data-grafico]")


function atualizaGrafico(elemento) {
  elemento.addEventListener((evento) => {
      if(atualizaGrafico = [data-grafico]){
        for(querySelectorAll(".circle"))
        return to 
      }
  })
})

function atualizaGrafico(operacao){
  if(operacao === "-")
}